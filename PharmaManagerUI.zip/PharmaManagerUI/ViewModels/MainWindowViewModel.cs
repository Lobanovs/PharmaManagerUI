﻿using PharmaManagerUI.Commands;
using PharmaManagerUI.Views;
using System.Windows;
using System.Windows.Input;

namespace PharmaManagerUI.ViewModels
{
    public class MainWindowViewModel
    {
        public string WelcomeMessage { get; }
        public ICommand NavigateCommand { get; }
        public ICommand LogoutCommand { get; }

        public MainWindowViewModel(string role)
        {
            WelcomeMessage = $"Добро пожаловать! Ваша роль: {role}";
            NavigateCommand = new RelayCommand(Navigate, CanNavigate);
            LogoutCommand = new RelayCommand(Logout, CanLogout);
        }

        private void Navigate(object parameter)
        {
            string entity = parameter as string;
            MessageBox.Show($"Открытие раздела: {entity}", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private bool CanNavigate(object parameter) => true;

        private void Logout(object parameter)
        {
            var loginWindow = new LoginWindow();
            loginWindow.Show();
            Application.Current.Windows.OfType<MainWindow>().First().Close();
        }

        private bool CanLogout(object parameter) => true;
    }
}