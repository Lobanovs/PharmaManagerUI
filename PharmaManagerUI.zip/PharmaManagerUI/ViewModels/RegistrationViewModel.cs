﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using PharmaManagerUI.Commands;
using PharmaManagerUI.Data;
using PharmaManagerUI.Models;
using PharmaManagerUI.Services;
using PharmaManagerUI.Views;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;

namespace PharmaManagerUI.ViewModels
{
    public class RegistrationViewModel : INotifyPropertyChanged
    {
        private string _login;
        private string _role;

        public string Login
        {
            get => _login;
            set { _login = value; OnPropertyChanged(); }
        }

        public string Role
        {
            get => _role;
            set { _role = value; OnPropertyChanged(); }
        }

        public ICommand RegisterCommand { get; }

        public RegistrationViewModel()
        {
            RegisterCommand = new RelayCommand(Register, CanRegister);
        }

        private void Register(object parameter)
        {
            var window = parameter as RegistrationWindow;
            var password = window.passwordBox.Password;
            var confirmPassword = window.confirmPasswordBox.Password;

            if (string.IsNullOrEmpty(password) || password != confirmPassword)
            {
                MessageBox.Show("Пароли не совпадают или пусты!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                var configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json")
                    .Build();

                var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
                optionsBuilder.UseSqlServer(configuration.GetConnectionString("PharmaManagerDB"));

                using (var context = new AppDbContext(optionsBuilder.Options))
                {
                    if (context.Users.Any(u => u.Login == Login))
                    {
                        MessageBox.Show("Пользователь с таким логином уже существует!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    var (hash, salt) = PasswordService.HashPassword(password);
                    var user = new User
                    {
                        Login = Login,
                        PasswordHash = hash,
                        Salt = salt,
                        Role = Role
                    };

                    context.Users.Add(user);
                    context.SaveChanges();

                    MessageBox.Show("Регистрация успешна!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    window.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при регистрации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool CanRegister(object parameter) => !string.IsNullOrEmpty(Login) && !string.IsNullOrEmpty(Role);

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}