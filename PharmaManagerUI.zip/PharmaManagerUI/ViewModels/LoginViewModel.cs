﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using PharmaManagerUI.Commands;
using PharmaManagerUI.Data;
using PharmaManagerUI.Services;
using PharmaManagerUI.Views;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;

namespace PharmaManagerUI.ViewModels
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        private string _login;

        public string Login
        {
            get => _login;
            set { _login = value; OnPropertyChanged(); }
        }

        public ICommand LoginCommand { get; }

        public LoginViewModel()
        {
            LoginCommand = new RelayCommand(SignIn, CanSignIn);
        }

        private void SignIn(object parameter)
        {
            var window = parameter as LoginWindow;
            var password = window.passwordBox.Password;

            try
            {
                var configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json")
                    .Build();

                var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
                optionsBuilder.UseSqlServer(configuration.GetConnectionString("PharmaManagerDB"));

                using (var context = new AppDbContext(optionsBuilder.Options))
                {
                    var user = context.Users.FirstOrDefault(u => u.Login == this.Login);
                    if (user != null && PasswordService.VerifyPassword(password, user.PasswordHash, user.Salt))
                    {
                        MessageBox.Show($"Добро пожаловать, {user.Role}!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        var mainWindow = new MainWindow(user.Role);
                        mainWindow.Show();
                        window.Close();
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при входе: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool CanSignIn(object parameter) => !string.IsNullOrEmpty(this.Login);

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}